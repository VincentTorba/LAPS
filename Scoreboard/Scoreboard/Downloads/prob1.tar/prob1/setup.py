# this is the hack

cmd = "sshpass -p'goodyear123!@#' ssh -tt root@192.168.1.8 service httpd stop";
import os;
os.system(cmd);

