print(10);

